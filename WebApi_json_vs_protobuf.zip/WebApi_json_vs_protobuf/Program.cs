﻿using BeetleX.Buffers;
using BeetleX.EventArgs;
using BeetleX.FastHttpApi;
using Northwind.Data;
using System;
using System.Collections.Generic;

namespace WebApi_json_vs_protobuf
{

    class Program
    {
        private static HttpApiServer mApiServer;
        static void Main(string[] args)
        {
            mApiServer = new HttpApiServer();
            mApiServer.ServerConfig.LogLevel = LogType.Warring;//Warring
            mApiServer.ServerConfig.Port = 8080;
            mApiServer.ServerConfig.LogToConsole = true;
            mApiServer.Register(typeof(Program).Assembly);
            mApiServer.Open();
            Console.Read();
        }
    }
    [Controller(BaseUrl = "/")]
    public class Controller
    {
        [Get(Route = "{count}")]
        [ProtobufResultFilter]
        public object Customers_protobuf(int count)
        {
            List<Customer> result = new List<Customer>();
            if (count > DataHelper.Defalut.Customers.Count)
                count = DataHelper.Defalut.Customers.Count;
            for (int i = 0; i < count; i++)
            {
                result.Add(DataHelper.Defalut.Customers[i]);
            }
            return result;
        }
        [Get(Route = "{count}")]
        [DefaultJsonResultFilter]
        public object Customers_json(int count)
        {
            List<Customer> result = new List<Customer>();
            if (count > DataHelper.Defalut.Customers.Count)
                count = DataHelper.Defalut.Customers.Count;
            for (int i = 0; i < count; i++)
            {
                result.Add(DataHelper.Defalut.Customers[i]);
            }
            return result;
        }
    }

    public class ProtobufResult : ResultBase
    {

        public ProtobufResult(object data)
        {
            Data = data;
        }

        public object Data { get; set; }

        public override string ContentType => "application/x-protobuf";

        public override void Write(PipeStream stream, HttpResponse response)
        {
            if (Data != null)
            {
                ProtoBuf.Meta.RuntimeTypeModel.Default.Serialize(stream, Data);
            }
        }
    }

    public class ProtobufResultFilter : FilterAttribute
    {
        public override void Executed(ActionContext context)
        {
            context.Result = new ProtobufResult(context.Result);
        }
    }
}
